public class token {
    public String ID;
    public String Class;
    public String contents;
    
    public token(String a,String b,String c)
    {

        this.ID=a;
        this.Class=b;
        this.contents=c;
    }
}
