public class SemanticError {
    String message = "";
    String line = "";
    public SemanticError(String message ,String line)
    {
        this.line = line;
        this.message = message;
    }
}


