public class State
{
    public String full;
    public String partial;
    public int position;
    public int line;
    public State next;

    public State() {}

    public void resolve() throws Exception { }
}
