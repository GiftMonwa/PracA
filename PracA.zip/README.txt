The file that is used as an input source is the input.txt file
This is where you can add input to test the Lexer and Parser with

The Lexer:
The Lexer Tokenizes this input file and writes the tokens to Lexer.txt
Therefore the lexer output is found in Lexer.txt

The Parser:
Uses the Lexer tokens and outputs an xml



To Run the file:
run two commands on windows:
1-javac *.java
2-java Main


If needed ->
The Java version Used for the prac:
java 16 2021-03-16
Java(TM) SE Runtime Environment (build 16+36-2231)