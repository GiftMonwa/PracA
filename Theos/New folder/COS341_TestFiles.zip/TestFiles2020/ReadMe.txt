(((((( Assuming that the prac spec is the same as last year ))))))

All these files should compile successfully.

Some things might not work if its meant for a later phase in the compiler.

Make sure you build the Token List, Symbol Table and Syntax Tree properly
because you will be traversing it alot for the rest of the practicals.

